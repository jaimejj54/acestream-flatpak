const e="Сервис заблокирован",c={service_blocked:e};export{c as default,e as service_blocked};
